//barebones
$(document).ready(function(){
    istar.setupModel();
    istar.setupMetamodel(istar.metamodel);
});

// graphical
// $(document).ready(function(){
//     istar.setupModel();
//     istar.setupDiagram();
//     istar.setupMetamodel(istarcoreMetamodel);
//     ui.defineInteractions();
//     //wikiExample();
//     elementsExample();
// });
