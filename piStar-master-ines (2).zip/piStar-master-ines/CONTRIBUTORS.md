﻿# List of Contributors
*To see which contributions each individual made to this project, check our commit history*

#### Design and development
* João Pimentel

#### Art
* [Slice of pie art](https://www.svgrepo.com/svg/96040/slice-of-cake) 
adapted from an image of the 
[Having Brunch vectors collection](https://www.svgrepo.com/vectors/having-brunch/)
, author unknown
, licensed with [Creative Commons BY 4.0](https://creativecommons.org/licenses/by/4.0/).
* [Star art](https://commons.wikimedia.org/wiki/File:Five_Pointed_Star_Solid.svg)
authored by Wikimedia user Indolences
, published in the public domain.